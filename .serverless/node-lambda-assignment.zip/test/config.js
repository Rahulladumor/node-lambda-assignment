const chai = require('chai');
const chaiHttp = require('chai-http');
const server = 'https://4hx59wj9ng.execute-api.us-east-1.amazonaws.com/dev'; // api gateway url
module.exports = { chai, chaiHttp, server };