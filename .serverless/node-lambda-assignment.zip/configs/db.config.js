const { Sequelize } = require('sequelize');

module.exports = new Sequelize('vPgBXqk5jt', 'vPgBXqk5jt', 'kiuS2Aehym', {
  host: 'remotemysql.com',
  dialect: 'mysql'
});
